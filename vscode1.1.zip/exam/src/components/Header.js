import { useEffect, useRef, useState } from "react"

export default function Header(props) {
    const [name, setName] = useState('Dhaval');
    const [text, setText] = useState('')
    let nameInput = useRef('');
    console.log(nameInput.current.value);
    // useEffect(() => {
    // setName('Jeet');
    // }, []);

    function changeName() {
        setName('Jeet')
    }
    // function myFunction() {
    // setText(nameInput.current.value);
    // }
    return (
        <>
            <h1>{props.title}</h1>
            <h1>{props.description}</h1>
            <h1>{name}</h1>
            <h2>{text}</h2>
            <button onClick={changeName}>Click</button>
            <form>
                <label></label>
                <input type='text' onChange={(j) => setText(j.target.value)} />
                {/* <button type='button' onClick={myFunction}>Clickme</button> */}
            </form>
        </>
    )
}