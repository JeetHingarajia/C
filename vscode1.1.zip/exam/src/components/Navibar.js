import React from 'react';
import { Link } from 'react-router-dom';

export default function Navibar() {
    return (
        <nav className='flex justify-between items-center p-5 bg-amber-400'>
            <ul className='flex'>
                <li>
                    <Link to="/">Header</Link>
                </li>
                <li>
                    <Link to="/fetch">Fetch</Link>
                </li>
            </ul>
        </nav>
    );
}
