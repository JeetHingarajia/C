import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import FetchData from "./components/FetchData";
import Header from "./components/Header";
//import Navbar from './components/Navibar';
import Navibar from './components/Navibar';


function App() {
  return (

    <Router>
      <div className='App'>
        <Navibar />
        <Routes>
          <Route path='/' element={<Header title="This is Header..." description="Jeetubhai" />} />
          <Route path='/fetch' element={<FetchData />} />
        </Routes>
      </div>
    </Router >
  );
}

export default App;
