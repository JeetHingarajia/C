import React from "react";

function Filter() {
    const data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    const iseven = (value) => value % 2 === 0;

    const even = data.filter(iseven);

    return (
        <>
            <p>{even}</p>
        </>
    )
}

export default Filter;