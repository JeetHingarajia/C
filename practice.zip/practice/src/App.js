import './App.css';
import { Card } from './components/Card';
import FetchData from './components/FetchData';
import Input from './components/Input';
import Filter from './Filter';

function App() {


  return (

    <div className="App">
      <Card title="Card Component" />
      <Input />
      <FetchData />
      <Filter />
    </div>
  );
}

export default App;
